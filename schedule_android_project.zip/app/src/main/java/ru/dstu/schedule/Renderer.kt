package ru.dstu.schedule

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.TextStyle
import java.util.Date
import java.util.Locale

// ---------- палитра ----------
private val TEXT = Color.WHITE
private val SUB = Color.parseColor("#9A9AB0")
private val DIMC = Color.argb(97, 255, 255, 255)
private val ACCENT = Color.parseColor("#0A84FF")
private val NEXTC = Color.parseColor("#BF5AF2")
private val LATERC = Color.parseColor("#6E6E8A")
private val PASTC = Color.parseColor("#4A4A5E")
private val OKC = Color.parseColor("#30D158")
private val WARN = Color.parseColor("#FF9F0A")
private val NOW_BG = Color.argb(56, 10, 132, 255)
private val CARD_BG = Color.argb(15, 255, 255, 255)

// ---------- размеры (в dp) ----------
private const val PAD = 12f
private const val TOP_H = 18f
private const val DAY_H = 22f
private const val FULL_H = 32f
private const val COMP_H = 20f
private const val GAP_H = 13f
private const val SP = 6f
private const val MORE_H = 12f
private const val CARD_H = 8f
private const val EMPTY_H = 18f

private val RU = Locale("ru")

internal class Item(val l: Lesson, val s: LState)
internal class Level(val dropPast: Boolean, val cToday: Boolean, val cTom: Boolean)

internal class Scene(
    private val c: Canvas,
    private val w: Float,
    private val h: Float,
    private val now: LocalDateTime
) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val nowM = now.hour * 60 + now.minute
    var y = PAD

    // ---------- примитивы ----------
    private fun face(weight: Int): Typeface = when (weight) {
        2 -> Typeface.DEFAULT_BOLD
        1 -> medium
        else -> Typeface.DEFAULT
    }

    private fun measure(s: String, size: Float, weight: Int): Float {
        paint.typeface = face(weight)
        paint.textSize = size
        return paint.measureText(s)
    }

    private fun text(
        s: String, x: Float, base: Float, size: Float, color: Int,
        weight: Int = 0, maxW: Float = 100000f, right: Boolean = false
    ) {
        if (maxW < 10f || s.isEmpty()) return
        paint.typeface = face(weight)
        paint.textSize = size
        paint.color = color
        paint.style = Paint.Style.FILL
        paint.pathEffect = null
        paint.textAlign = if (right) Paint.Align.RIGHT else Paint.Align.LEFT
        var t = s
        val full = paint.measureText(t)
        if (full > maxW) {
            val k = maxW / full
            if (k >= 0.8f) {
                paint.textSize = size * k
            } else {
                paint.textSize = size * 0.8f
                while (t.length > 1 && paint.measureText(t + "…") > maxW) t = t.dropLast(1)
                t = t + "…"
            }
        }
        c.drawText(t, x, base, paint)
    }

    private fun rrect(l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.pathEffect = null
        c.drawRoundRect(RectF(l, t, r, b), rad, rad, paint)
    }

    private fun barColor(s: LState): Int = when (s) {
        LState.NOW -> ACCENT
        LState.NEXT -> NEXTC
        LState.LATER -> LATERC
        LState.PAST -> PASTC
    }

    // ---------- блоки ----------
    private fun topBar(snap: Snapshot) {
        text(Config.GROUP_NAME, PAD + 2f, y + 12f, 11f, ACCENT, 2)
        if (snap.updated > 0L) {
            val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(snap.updated))
            val label = (if (snap.online) "" else "оффлайн · ") + t
            text(label, w - PAD - 2f, y + 11f, 9f, if (snap.online) DIMC else WARN, 0, 120f, true)
        }
        y += TOP_H
    }

    private fun dayHeader(label: String, date: LocalDate, right: String, rightColor: Int) {
        text(label, PAD + 2f, y + 15f, 14f, TEXT, 2)
        val lw = measure(label, 14f, 2)
        val dow = date.dayOfWeek.getDisplayName(TextStyle.SHORT, RU).replaceFirstChar { it.uppercase() }
        val mon = date.month.getDisplayName(TextStyle.SHORT, RU)
        text("$dow, ${date.dayOfMonth} $mon", PAD + 2f + lw + 6f, y + 14.5f, 10f, SUB)
        text(right, w - PAD - 2f, y + 14.5f, 10f, rightColor, 1, w * 0.5f, true)
        y += DAY_H
    }

    private fun fullRow(l: Lesson, s: LState) {
        val past = s == LState.PAST
        val top = y
        if (s == LState.NOW) rrect(PAD, top, w - PAD, top + FULL_H, 9f, NOW_BG)
        rrect(PAD + 6f, top + 4f, PAD + 9f, top + 28f, 1.5f, barColor(s))
        val tx = PAD + 17f
        text(l.start, tx, top + 14f, 11f, if (past) DIMC else TEXT, 2, 42f)
        text(l.end, tx, top + 26f, 9f, if (past) DIMC else SUB, 0, 42f)
        val nx = tx + 46f
        val rightEdge = w - PAD - 6f
        val rw = if (s == LState.NOW || s == LState.NEXT) 86f else 0f
        val maxW = rightEdge - rw - nx - 4f
        text(l.name, nx, top + 14f, 12f, if (past) DIMC else TEXT, 1, maxW)
        val parts = ArrayList<String>()
        if (l.room.isNotEmpty()) parts.add("ауд. " + l.room)
        if (l.teacher.isNotEmpty()) parts.add(l.teacher)
        if (parts.isNotEmpty()) {
            text(parts.joinToString(" · "), nx, top + 26f, 9f, if (past) DIMC else SUB, 0, maxW)
        }
        if (s == LState.NOW) {
            val left = Logic.fmtDur(maxOf(1, Logic.minutes(l.end) - nowM))
            text("СЕЙЧАС", rightEdge, top + 13f, 8f, ACCENT, 2, 80f, true)
            text("до конца $left", rightEdge, top + 25f, 9f, ACCENT, 2, 84f, true)
        } else if (s == LState.NEXT) {
            val inn = Logic.fmtDur(maxOf(1, Logic.minutes(l.start) - nowM))
            text("ДАЛЕЕ", rightEdge, top + 13f, 8f, NEXTC, 2, 80f, true)
            text("через $inn", rightEdge, top + 25f, 9f, NEXTC, 2, 84f, true)
        }
        y += FULL_H
    }

    private fun compactRow(l: Lesson, s: LState) {
        val past = s == LState.PAST
        val top = y
        if (s == LState.NOW) rrect(PAD, top, w - PAD, top + COMP_H, 7f, NOW_BG)
        rrect(PAD + 6f, top + 3.5f, PAD + 9f, top + 16.5f, 1.5f, barColor(s))
        val tx = PAD + 15f
        text(l.start, tx, top + 14f, 11f, if (past) DIMC else TEXT, 2, 38f)
        val nx = tx + 40f
        val rightEdge = w - PAD - 6f
        val right: String
        val rc: Int
        if (s == LState.NOW) {
            right = Logic.fmtDur(maxOf(1, Logic.minutes(l.end) - nowM))
            rc = ACCENT
        } else {
            right = l.room
            rc = if (past) DIMC else SUB
        }
        val rw = if (right.isEmpty()) 0f else minOf(measure(right, 10f, 1), 72f) + 6f
        text(l.name, nx, top + 14f, 11f, if (past) DIMC else TEXT, 1, rightEdge - rw - nx)
        if (right.isNotEmpty()) text(right, rightEdge, top + 14f, 10f, rc, 1, 72f, true)
        y += COMP_H
    }

    private fun gapRow(prev: Lesson, next: Lesson, isToday: Boolean) {
        val gap = Logic.minutes(next.start) - Logic.minutes(prev.end)
        if (gap < Config.WINDOW_MIN) return
        val isNow = isToday && Logic.minutes(prev.end) <= nowM && nowM < Logic.minutes(next.start)
        val isPast = isToday && Logic.minutes(next.start) <= nowM
        val msg = if (isNow) {
            "сейчас окно · ещё " + Logic.fmtDur(Logic.minutes(next.start) - nowM)
        } else {
            "окно " + Logic.fmtDur(gap)
        }
        val col = if (isNow) OKC else if (isPast) DIMC else SUB
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = col
        paint.pathEffect = DashPathEffect(floatArrayOf(2f, 2f), 0f)
        c.drawLine(PAD + 18f, y + 7f, PAD + 32f, y + 7f, paint)
        paint.pathEffect = null
        paint.style = Paint.Style.FILL
        text(msg, PAD + 36f, y + 10f, 9f, col, if (isNow) 1 else 0)
        y += GAP_H
    }

    private fun more(n: Int) {
        if (n <= 0) return
        text("+ ещё $n", PAD + 18f, y + 9f, 9f, SUB)
        y += MORE_H
    }

    private fun empty(known: Boolean) {
        text(if (known) "Пар нет 🎉" else "Нет данных (оффлайн)", PAD + 2f, y + 13f, 12f, SUB)
        y += EMPTY_H
    }

    private fun list(items: List<Item>, compact: Boolean, isToday: Boolean) {
        for ((i, x) in items.withIndex()) {
            if (compact) {
                compactRow(x.l, x.s)
            } else {
                if (i > 0) gapRow(items[i - 1].l, x.l, isToday)
                fullRow(x.l, x.s)
            }
        }
    }

    private fun listH(items: List<Item>, compact: Boolean): Float {
        if (items.isEmpty()) return EMPTY_H
        if (compact) return items.size * COMP_H
        return items.size * FULL_H + Logic.countGaps(items.map { it.l }) * GAP_H
    }

    private fun wrap(s: String, size: Float, maxW: Float): List<String> {
        val out = ArrayList<String>()
        var cur = ""
        for (word in s.split(" ")) {
            val t = if (cur.isEmpty()) word else "$cur $word"
            if (measure(t, size, 0) > maxW && cur.isNotEmpty()) {
                out.add(cur)
                cur = word
            } else {
                cur = t
            }
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }

    private fun message(msg: String) {
        var yy = y + 20f
        for (ln in wrap(msg, 12f, w - 2 * PAD)) {
            text(ln, PAD + 2f, yy, 12f, TEXT)
            yy += 16f
        }
    }

    // ---------- режимы ----------
    fun draw(snap: Snapshot) {
        topBar(snap)
        if (snap.known.isEmpty()) {
            message(snap.error ?: "Нет данных. Открой приложение при включённом интернете.")
            return
        }
        val today = now.toLocalDate()
        val tomorrow = today.plusDays(1)
        val nowStr = String.format(Locale.US, "%02d:%02d", now.hour, now.minute)
        val todayL = Logic.mergeSlots(snap.days[today.toString()] ?: emptyList())
        val tomL = Logic.mergeSlots(snap.days[tomorrow.toString()] ?: emptyList())
        val todayKnown = snap.known.contains(today.toString())
        val tomKnown = snap.known.contains(tomorrow.toString())
        val st = Logic.computeStates(todayL, nowStr)
        val todAll = todayL.mapIndexed { i, l -> Item(l, st[i]) }
        val tomAll = tomL.map { Item(it, LState.LATER) }
        val past = todAll.count { it.s == LState.PAST }
        val allDone = todAll.isNotEmpty() && past == todAll.size
        val span = if (tomAll.isNotEmpty()) tomAll.first().l.start + "–" + tomAll.last().l.end else ""

        if (h >= 240f) {
            twoDays(today, tomorrow, todAll, tomAll, past, allDone, todayKnown, tomKnown, span)
        } else {
            oneDay(today, tomorrow, todAll, tomAll, todayKnown, tomKnown, span)
        }
    }

    private fun twoDays(
        today: LocalDate, tomorrow: LocalDate,
        todAll: List<Item>, tomAll: List<Item>,
        past: Int, allDone: Boolean,
        todayKnown: Boolean, tomKnown: Boolean, span: String
    ) {
        val avail = h - PAD - y
        val levels = listOf(
            Level(false, false, false),
            Level(true, false, false),
            Level(true, false, true),
            Level(true, true, true)
        )
        fun calc(lv: Level, tod: List<Item>, tom: List<Item>): Float {
            return DAY_H + listH(tod, lv.cToday) + SP + DAY_H + listH(tom, lv.cTom) +
                (if (lv.cTom && tom.isNotEmpty()) CARD_H else 0f)
        }

        var lv = levels.last()
        var tod = todAll.filter { it.s != LState.PAST }
        var tom = tomAll
        for (cand in levels) {
            val t1 = if (cand.dropPast) todAll.filter { it.s != LState.PAST } else todAll
            if (calc(cand, t1, tomAll) <= avail) {
                lv = cand
                tod = t1
                tom = tomAll
                break
            }
        }

        // крайний случай: даже компактно не лезет — обрезаем с пометкой «+ ещё N»
        var hiddenT = 0
        var hiddenM = 0
        while (calc(lv, tod, tom) + (if (hiddenT > 0) MORE_H else 0f) + (if (hiddenM > 0) MORE_H else 0f) > avail) {
            if (tom.size > 2) {
                tom = tom.dropLast(1)
                hiddenM++
            } else if (tod.size > 1) {
                tod = tod.dropLast(1)
                hiddenT++
            } else {
                break
            }
        }

        val todayRight = Logic.dayRight(todayKnown, allDone, todAll.size, if (lv.dropPast) past else 0, "")
        dayHeader("Сегодня", today, todayRight, if (allDone) OKC else SUB)
        if (tod.isEmpty() && !allDone) empty(todayKnown)
        list(tod, lv.cToday, true)
        more(hiddenT)

        y += SP
        dayHeader("Завтра", tomorrow, Logic.dayRight(tomKnown, false, tomAll.size, 0, span), SUB)
        if (tom.isEmpty()) {
            empty(tomKnown)
        } else if (lv.cTom) {
            // компактный завтрашний день — аккуратной карточкой
            rrect(PAD, y, w - PAD, y + tom.size * COMP_H + CARD_H, 10f, CARD_BG)
            y += CARD_H / 2f
            list(tom, true, false)
            y += CARD_H / 2f
        } else {
            list(tom, false, false)
        }
        more(hiddenM)
    }

    private fun oneDay(
        today: LocalDate, tomorrow: LocalDate,
        todAll: List<Item>, tomAll: List<Item>,
        todayKnown: Boolean, tomKnown: Boolean, span: String
    ) {
        val left = todAll.filter { it.s != LState.PAST }
        val useToday = left.isNotEmpty()
        val items = if (useToday) left else tomAll
        val date = if (useToday) today else tomorrow
        val known = if (useToday) todayKnown else tomKnown
        dayHeader(
            if (useToday) "Сегодня" else "Завтра", date,
            Logic.dayRight(known, false, items.size, 0, if (useToday) "" else span), SUB
        )
        if (items.isEmpty()) {
            empty(known)
            return
        }
        val availList = h - PAD - y
        var compact = false
        var shown = items
        if (listH(items, false) > availList) {
            compact = true
            var maxRows = (availList / COMP_H).toInt()
            if (items.size > maxRows) {
                maxRows = ((availList - MORE_H) / COMP_H).toInt()
                shown = items.take(maxOf(1, maxRows))
            }
        }
        list(shown, compact, useToday)
        more(items.size - shown.size)
    }
}

object Renderer {
    private var bgBmp: Bitmap? = null
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    private fun bg(ctx: Context): Bitmap? {
        if (bgBmp == null) {
            try {
                bgBmp = BitmapFactory.decodeResource(ctx.resources, R.drawable.bg)
            } catch (e: Exception) {
                // без картинки — просто чёрный фон
            }
        }
        return bgBmp
    }

    private fun drawBackground(ctx: Context, c: Canvas, w: Float, h: Float) {
        c.drawColor(Color.BLACK)
        val bmp = bg(ctx) ?: return
        val iw = bmp.width.toFloat()
        val ih = bmp.height.toFloat()
        val dst: RectF
        if (h / w > 0.8f) {
            // почти квадрат или выше: на всю ширину по центру (картинка сама на чёрном фоне)
            val dh = w * ih / iw
            dst = RectF(0f, (h - dh) / 2f, w, (h + dh) / 2f)
        } else {
            val sc = maxOf(w / iw, h / ih)
            val dw = iw * sc
            val dh = ih * sc
            val dx = if (w < 200f) 0f else (w - dw) / 2f
            dst = RectF(dx, (h - dh) / 2f, dx + dw, (h + dh) / 2f)
        }
        c.drawBitmap(bmp, null, dst, bmpPaint)
        val p = Paint()
        p.color = Color.argb((Config.BG_DIM * 255f).toInt(), 0, 0, 0)
        c.drawRect(0f, 0f, w, h, p)
    }

    /** Рисует виджет в Bitmap. Размер wDp x hDp — в dp */
    fun render(ctx: Context, wDp: Int, hDp: Int, snap: Snapshot, now: LocalDateTime): Bitmap {
        var scale = ctx.resources.displayMetrics.density
        val maxPixels = 1_000_000f // ограничение по размеру bitmap для RemoteViews
        val area = wDp.toFloat() * hDp.toFloat() * scale * scale
        if (area > maxPixels) scale *= Math.sqrt((maxPixels / area).toDouble()).toFloat()
        val bw = maxOf(1, (wDp * scale).toInt())
        val bh = maxOf(1, (hDp * scale).toInt())
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(scale, scale)
        val w = wDp.toFloat()
        val h = hDp.toFloat()
        val clip = Path()
        clip.addRoundRect(RectF(0f, 0f, w, h), 18f, 18f, Path.Direction.CW)
        c.clipPath(clip)
        drawBackground(ctx, c, w, h)
        Scene(c, w, h, now).draw(snap)
        return bmp
    }
}
