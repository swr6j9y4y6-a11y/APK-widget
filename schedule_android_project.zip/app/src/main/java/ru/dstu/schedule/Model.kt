package ru.dstu.schedule

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

data class Lesson(
    val start: String,
    val end: String,
    val name: String,
    val room: String,
    val teacher: String
)

enum class LState { PAST, NOW, NEXT, LATER }

class Snapshot(
    val days: Map<String, List<Lesson>>,
    val known: Set<String>,
    val updated: Long,
    val online: Boolean,
    val error: String?
)

/** Чистая логика: подгруппы, состояния пар, форматирование */
object Logic {
    fun minutes(hm: String): Int {
        return try {
            val p = hm.split(":")
            p[0].trim().toInt() * 60 + p[1].trim().toInt()
        } catch (e: Exception) {
            0
        }
    }

    fun fmtDur(min: Int): String {
        if (min < 60) return "$min мин"
        val h = min / 60
        val m = min % 60
        return if (m > 0) "$h ч $m мин" else "$h ч"
    }

    fun pairs(n: Int): String {
        val a = n % 10
        val b = n % 100
        return when {
            a == 1 && b != 11 -> "$n пара"
            a in 2..4 && (b < 12 || b > 14) -> "$n пары"
            else -> "$n пар"
        }
    }

    fun shortName(full: String): String {
        val p = full.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (p.size < 2) return full.trim()
        return p[0] + " " + p.drop(1).joinToString("") { it.take(1) + "." }
    }

    private class Acc(val start: String, val end: String) {
        val names = ArrayList<String>()
        val rooms = ArrayList<String>()
        val teachers = ArrayList<String>()
    }

    /** Несколько записей в одно время (подгруппы) считаем одной парой */
    fun mergeSlots(lessons: List<Lesson>): List<Lesson> {
        val map = LinkedHashMap<String, Acc>()
        for (l in lessons) {
            val a = map.getOrPut(l.start + "|" + l.end) { Acc(l.start, l.end) }
            if (l.name.isNotEmpty() && !a.names.contains(l.name)) a.names.add(l.name)
            if (l.room.isNotEmpty() && !a.rooms.contains(l.room)) a.rooms.add(l.room)
            val t = shortName(l.teacher)
            if (t.isNotEmpty() && !a.teachers.contains(t)) a.teachers.add(t)
        }
        return map.values.map {
            Lesson(
                it.start,
                it.end,
                it.names.joinToString(" / "),
                it.rooms.joinToString(" / "),
                it.teachers.joinToString(", ")
            )
        }.sortedBy { it.start }
    }

    fun computeStates(lessons: List<Lesson>, nowStr: String): List<LState> {
        var nextSet = false
        val out = ArrayList<LState>()
        for (l in lessons) {
            if (l.end <= nowStr) {
                out.add(LState.PAST)
            } else if (l.start <= nowStr) {
                out.add(LState.NOW)
            } else if (!nextSet) {
                nextSet = true
                out.add(LState.NEXT)
            } else {
                out.add(LState.LATER)
            }
        }
        return out
    }

    fun countGaps(l: List<Lesson>): Int {
        var n = 0
        for (i in 1 until l.size) {
            if (minutes(l[i].start) - minutes(l[i - 1].end) >= Config.WINDOW_MIN) n++
        }
        return n
    }

    /** Подпись справа в заголовке дня */
    fun dayRight(known: Boolean, allDone: Boolean, total: Int, past: Int, span: String): String {
        if (!known) return "нет данных"
        if (total == 0) return ""
        if (allDone) return "всё прошло"
        var s = if (past > 0) "прошло $past из $total" else pairs(total)
        if (span.isNotEmpty()) s = "$span · $s"
        return s
    }
}

/** Загрузка расписания с edu.donstu.ru + кэш на устройстве */
object Repo {
    private const val PREFS = "schedule"

    private fun JSONObject.str(key: String): String {
        if (isNull(key)) return ""
        return optString(key, "")
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.requestMethod = "GET"
        try {
            if (c.responseCode != 200) throw RuntimeException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun groupId(ctx: Context): Long {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (sp.contains("groupId")) return sp.getLong("groupId", -1L)
        val now = LocalDate.now()
        val y = now.year
        val year = if (now.monthValue >= 8) "$y-${y + 1}" else "${y - 1}-$y"
        val root = JSONObject(httpGet("${Config.BASE}/raspGrouplist?year=$year"))
        val arr = root.optJSONArray("data") ?: throw RuntimeException("Не удалось получить список групп")
        val want = Config.GROUP_NAME.replace(Regex("\\s"), "").uppercase()
        for (i in 0 until arr.length()) {
            val g = arr.getJSONObject(i)
            val name = g.str("name").replace(Regex("\\s"), "").uppercase()
            if (name == want) {
                val id = g.getLong("id")
                sp.edit().putLong("groupId", id).apply()
                return id
            }
        }
        throw RuntimeException("Группа ${Config.GROUP_NAME} не найдена")
    }

    private class Cache {
        val days = LinkedHashMap<String, List<Lesson>>()
        val known = LinkedHashSet<String>()
        var updated = 0L
    }

    private fun readCache(ctx: Context): Cache {
        val c = Cache()
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("cache", null) ?: return c
        try {
            val o = JSONObject(raw)
            c.updated = o.optLong("updated", 0L)
            val kn = o.optJSONArray("known")
            if (kn != null) {
                for (i in 0 until kn.length()) c.known.add(kn.getString(i))
            }
            val d = o.optJSONObject("days")
            if (d != null) {
                val keys = d.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val arr = d.getJSONArray(k)
                    val list = ArrayList<Lesson>()
                    for (i in 0 until arr.length()) {
                        val l = arr.getJSONObject(i)
                        list.add(Lesson(l.str("s"), l.str("e"), l.str("n"), l.str("r"), l.str("t")))
                    }
                    c.days[k] = list
                }
            }
        } catch (e: Exception) {
            // битый кэш — игнорируем
        }
        return c
    }

    private fun writeCache(ctx: Context, c: Cache) {
        val o = JSONObject()
        o.put("updated", c.updated)
        val kn = JSONArray()
        for (k in c.known) kn.put(k)
        o.put("known", kn)
        val d = JSONObject()
        for ((k, list) in c.days) {
            val arr = JSONArray()
            for (l in list) {
                val j = JSONObject()
                j.put("s", l.start)
                j.put("e", l.end)
                j.put("n", l.name)
                j.put("r", l.room)
                j.put("t", l.teacher)
                arr.put(j)
            }
            d.put(k, arr)
        }
        o.put("days", d)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("cache", o.toString()).apply()
    }

    private fun mondayOf(d: LocalDate): LocalDate = d.minusDays((d.dayOfWeek.value - 1).toLong())

    private fun syncWeek(id: Long, date: LocalDate, c: Cache) {
        val root = JSONObject(httpGet("${Config.BASE}/Rasp?idGroup=$id&sdate=$date"))
        val rasp = root.optJSONObject("data")?.optJSONArray("rasp") ?: JSONArray()
        val mon = mondayOf(date)
        val fresh = LinkedHashMap<String, ArrayList<Lesson>>()
        for (i in 0 until 7) {
            fresh[mon.plusDays(i.toLong()).toString()] = ArrayList()
        }
        var matched = 0
        for (i in 0 until rasp.length()) {
            val x = rasp.getJSONObject(i)
            val k = x.str("дата").take(10)
            val list = fresh[k] ?: continue
            matched++
            val name = x.str("дисциплина")
            list.add(
                Lesson(
                    x.str("начало").take(5),
                    x.str("конец").take(5),
                    if (name.isEmpty()) "?" else name,
                    x.str("аудитория"),
                    x.str("преподаватель")
                )
            )
        }
        if (rasp.length() > 0 && matched == 0) throw RuntimeException("Неожиданный формат ответа API")
        for ((k, v) in fresh) {
            c.days[k] = v.sortedBy { it.start }
            c.known.add(k)
        }
    }

    fun load(ctx: Context, dates: List<LocalDate>): Snapshot {
        val c = readCache(ctx)
        var online = true
        var error: String? = null
        try {
            val id = groupId(ctx)
            val done = HashSet<String>()
            for (d in dates) {
                val mon = mondayOf(d).toString()
                if (!done.add(mon)) continue
                syncWeek(id, d, c)
                c.updated = System.currentTimeMillis()
            }
        } catch (e: Exception) {
            online = false
            val m = e.message ?: ""
            if (m.startsWith("Неожиданный") || m.startsWith("Группа")) error = m
        }
        val limit = LocalDate.now().minusDays(14).toString()
        c.days.keys.removeAll { it < limit }
        c.known.removeAll { it < limit }
        writeCache(ctx, c)
        return Snapshot(c.days, c.known, c.updated, online, error)
    }
}
