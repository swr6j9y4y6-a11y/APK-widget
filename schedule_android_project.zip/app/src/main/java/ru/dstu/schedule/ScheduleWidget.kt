package ru.dstu.schedule

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.RemoteViews
import java.time.LocalDateTime
import java.util.Locale

class ScheduleWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        refresh(context, goAsync())
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions)
        refresh(context, goAsync())
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Config.ACTION_REFRESH) {
            refresh(context, goAsync())
        } else {
            super.onReceive(context, intent)
        }
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmIntent(context))
    }

    companion object {

        fun requestUpdate(ctx: Context) {
            refresh(ctx, null)
        }

        private fun refresh(ctx: Context, pending: BroadcastReceiver.PendingResult?) {
            val app = ctx.applicationContext
            Thread {
                try {
                    doRefresh(app)
                } catch (e: Exception) {
                    // не роняем процесс из-за ошибки сети/данных
                } finally {
                    pending?.finish()
                }
            }.start()
        }

        private fun alarmIntent(ctx: Context): PendingIntent {
            val i = Intent(ctx, ScheduleWidget::class.java)
            i.action = Config.ACTION_REFRESH
            return PendingIntent.getBroadcast(
                ctx, 1, i,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        private fun doRefresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ScheduleWidget::class.java))
            if (ids.isEmpty()) return

            val now = LocalDateTime.now()
            val today = now.toLocalDate()
            val snap = Repo.load(ctx, listOf(today, today.plusDays(1)))

            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            for (id in ids) {
                val opts = mgr.getAppWidgetOptions(id)
                var w = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
                var h = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
                if (w <= 0) w = 300
                if (h <= 0) h = 300
                val bmp = Renderer.render(ctx, w, h, snap, now)
                val views = RemoteViews(ctx.packageName, R.layout.widget_layout)
                views.setImageViewBitmap(R.id.widget_image, bmp)
                views.setOnClickPendingIntent(R.id.widget_root, open)
                mgr.updateAppWidget(id, views)
            }
            scheduleNext(ctx, snap, now)
        }

        /** Следующее обновление: к началу/концу ближайшей пары, но не реже чем раз в 15 минут */
        private fun scheduleNext(ctx: Context, snap: Snapshot, now: LocalDateTime) {
            val nowMs = System.currentTimeMillis()
            var next = nowMs + 15 * 60_000L
            val lessons = Logic.mergeSlots(snap.days[now.toLocalDate().toString()] ?: emptyList())
            val nowStr = String.format(Locale.US, "%02d:%02d", now.hour, now.minute)
            val edges = lessons.flatMap { listOf(it.start, it.end) }.filter { it > nowStr }.sorted()
            if (edges.isNotEmpty()) {
                val diffMin = Logic.minutes(edges[0]) - (now.hour * 60 + now.minute)
                val t = nowMs + diffMin * 60_000L - now.second * 1000L + 5_000L
                if (t < next) next = t
            }
            if (next < nowMs + 120_000L) next = nowMs + 120_000L
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            // неточный будильник без пробуждения телефона: сработает, когда телефон проснётся
            am.setAndAllowWhileIdle(AlarmManager.RTC, next, alarmIntent(ctx))
        }
    }
}
