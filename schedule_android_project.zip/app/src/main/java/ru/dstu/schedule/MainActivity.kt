package ru.dstu.schedule

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.time.LocalDateTime
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var box: LinearLayout
    private val ru = Locale("ru")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val p = (16 * d).toInt()
        box.setPadding(p, p * 3, p, p * 2)
        scroll.addView(box)
        setContentView(scroll)
        reload()
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun reload() {
        box.removeAllViews()
        box.addView(tv("Загрузка…", 16f, Color.GRAY))
        Thread {
            try {
                val now = LocalDateTime.now()
                val today = now.toLocalDate()
                val dates = (0..7).map { today.plusDays(it.toLong()) }
                val snap = Repo.load(applicationContext, dates)
                runOnUiThread { show(snap, now) }
                ScheduleWidget.requestUpdate(applicationContext)
            } catch (e: Exception) {
                runOnUiThread {
                    box.removeAllViews()
                    box.addView(tv("Ошибка: " + (e.message ?: ""), 14f, Color.RED))
                }
            }
        }.start()
    }

    private fun show(snap: Snapshot, now: LocalDateTime) {
        box.removeAllViews()
        box.addView(tv(Config.GROUP_NAME + " · расписание", 22f, Color.WHITE, true))
        var status = if (snap.online) "Данные обновлены" else "Оффлайн, данные из кэша"
        if (snap.error != null) status += "\n" + snap.error
        box.addView(tv(status, 12f, Color.GRAY))

        val btn = Button(this)
        btn.text = "Обновить"
        btn.setOnClickListener { reload() }
        box.addView(btn)
        box.addView(tv("Виджет: долгое нажатие на рабочем столе → Виджеты → Расписание ДГТУ", 12f, Color.GRAY))

        val nowStr = String.format(Locale.US, "%02d:%02d", now.hour, now.minute)
        val blue = Color.parseColor("#0A84FF")
        val gray = Color.parseColor("#9A9AB0")
        for (i in 0..6) {
            val d = now.toLocalDate().plusDays(i.toLong())
            val key = d.toString()
            val lessons = Logic.mergeSlots(snap.days[key] ?: emptyList())
            val known = snap.known.contains(key)
            val dow = d.dayOfWeek.getDisplayName(TextStyle.FULL, ru).replaceFirstChar { it.uppercase() }
            val prefix = if (i == 0) "Сегодня · " else if (i == 1) "Завтра · " else ""
            val title = "$prefix$dow, ${d.dayOfMonth} ${d.month.getDisplayName(TextStyle.FULL, ru)}"
            val head = tv(title, 17f, Color.WHITE, true)
            head.setPadding(0, 40, 0, 4)
            box.addView(head)
            if (!known) {
                box.addView(tv("нет данных", 13f, gray))
                continue
            }
            if (lessons.isEmpty()) {
                box.addView(tv("Пар нет 🎉", 13f, gray))
                continue
            }
            val states = if (i == 0) Logic.computeStates(lessons, nowStr) else lessons.map { LState.LATER }
            for ((j, l) in lessons.withIndex()) {
                if (j > 0) {
                    val gap = Logic.minutes(l.start) - Logic.minutes(lessons[j - 1].end)
                    if (gap >= Config.WINDOW_MIN) {
                        box.addView(tv("   окно " + Logic.fmtDur(gap), 12f, gray))
                    }
                }
                val col = when (states[j]) {
                    LState.NOW -> blue
                    LState.PAST -> Color.GRAY
                    else -> Color.WHITE
                }
                val line = tv(l.start + "–" + l.end + "   " + l.name, 15f, col, true)
                line.setPadding(0, 12, 0, 0)
                box.addView(line)
                val info = ArrayList<String>()
                if (l.room.isNotEmpty()) info.add("ауд. " + l.room)
                if (l.teacher.isNotEmpty()) info.add(l.teacher)
                if (info.isNotEmpty()) box.addView(tv(info.joinToString(" · "), 12f, gray))
            }
        }
    }
}
