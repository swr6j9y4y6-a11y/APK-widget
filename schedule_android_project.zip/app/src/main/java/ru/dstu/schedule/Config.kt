package ru.dstu.schedule

object Config {
    /** Название группы (как на сайте расписания) */
    const val GROUP_NAME = "ВИАС11"
    const val BASE = "https://edu.donstu.ru/api"

    /** Затемнение фоновой картинки 0..1 (больше — текст читается лучше) */
    const val BG_DIM = 0.55f

    /** Разрыв между парами (минут), начиная с которого показываем «окно» */
    const val WINDOW_MIN = 40

    const val ACTION_REFRESH = "ru.dstu.schedule.REFRESH"
}
